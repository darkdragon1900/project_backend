package com.drivewise.car.customexception;

public class ImagesNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ImagesNotFoundException(String msg) {
		super(msg);
}

}
